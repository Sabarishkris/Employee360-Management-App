package com.example.employee360.presentation.admin

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresExtension
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.updateTransition
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.employee360.R
import com.example.employee360.common.module.BottomNavigationItem
import com.example.employee360.common.module.DrawerItems
import com.example.employee360.common.module.MiniFabItems
//import com.example.employee360.presentation.MyNavigation
import com.example.employee360.common.util.Routes
import com.example.employee360.domain.viewmodel.AdminViewModel
import com.example.employee360.domain.viewmodel.LoginViewModel
import kotlinx.coroutines.launch


@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable

fun AdminMainScreen( loginViewModel: LoginViewModel= hiltViewModel(), viewModel: AdminViewModel = hiltViewModel(), navigate: NavHostController) {


    val drawerItem = listOf(
        DrawerItems(Icons.Filled.Home, " ABC Corporation Pvt ltd"),
        DrawerItems(Icons.Filled.Email, "admin@email.com"),
        DrawerItems(Icons.Filled.Phone, "+16 4986789546"),
        DrawerItems(Icons.Filled.Logout, "Sign Out")
    )
    val employees by viewModel.employee.collectAsState()


    val teams by viewModel.team.collectAsState()
    Log.d("Teamsized", "${teams.size}")

    val items = listOf(
        BottomNavigationItem(
            "Search",
            Routes.ADMIN_LIST_SCREEN,
            icon = Icons.Default.Search
        ), BottomNavigationItem(
            "Home",
            Routes.ADMIN_DASHBOARD_SCREEN,
            icon = Icons.Default.Home
        )
    )
    var selectedItem by remember {
        mutableStateOf(drawerItem[drawerItem.size - 1])
    }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    ModalNavigationDrawer(drawerContent = {
        ModalDrawerSheet(modifier = Modifier
            .fillMaxSize()
            .padding(end = 30.dp)) {

            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(250.dp),
//                        .background(MaterialTheme.colorScheme.onPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        Modifier.wrapContentSize(),
                        verticalArrangement = Arrangement.SpaceAround,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.admin),
                            contentDescription = "profile pic",
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = "Mr Admin",
                            Modifier
                                .fillMaxWidth()
                                .padding(top = 16.dp),
                            fontSize = 22.sp,
                            textAlign = TextAlign.Center
                        )

                    }
                }
                HorizontalDivider(
                    Modifier
                        .fillMaxWidth()
                        .padding(5.dp), thickness = 1.dp,
                    color = Color.DarkGray
                )
                    drawerItem.forEach {
                        NavigationDrawerItem(label = { Text(text = it.Name) },
                            selected = it == selectedItem,
                            onClick = {
                                if (it == selectedItem) {
                                    scope.launch {
                                        drawerState.close()
                                    }
                                    loginViewModel.deleteAllCredential()
                                    navigate.popBackStack(Routes.LOGIN_SCREEN, false)
                                }

                            },
                            modifier = Modifier.padding(horizontal = 16.dp),
                            icon = {
                                Icon(imageVector = it.icon, contentDescription = it.Name)
                            }
                        )

                }
            }
        }
    }, drawerState = drawerState) {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    if (viewModel.currentRoute == Routes.ADMIN_DASHBOARD_SCREEN) {
                        Text("Hello Admin")
                    } else if (viewModel.currentRoute == Routes.ADMIN_LIST_SCREEN) {
                        Text("Search")
                    } else if (viewModel.currentRoute == Routes.ADMIN_SETTING_SCREEN) {
                        Text("Setting")
                    }
                }, navigationIcon = {
                    IconButton(onClick = {
                        scope.launch {
                            drawerState.open()
                        }
                    }) {
                        Icon(imageVector = Icons.Filled.Menu, contentDescription = "menu Icon")
                    }

                }
                )
            },
            bottomBar = {
                BottomNavigation(items = items, currentScreen = viewModel.currentRoute) {
                    viewModel.currentRoute = it
                }
            }, floatingActionButton = {
                if(viewModel.currentRoute==Routes.ADMIN_LIST_SCREEN)
                MainUI(navigate)
            }
        ) { innerpadding ->
            when (viewModel.currentRoute) {
                Routes.ADMIN_DASHBOARD_SCREEN -> {
                    AdminDashboardScreen(viewModel,navigate,
                        employees = employees,
                        teams = teams,
                        modifier = Modifier.padding(innerpadding)
                    )
                }

                Routes.ADMIN_LIST_SCREEN -> {
                    AdminListScreen(viewModel,
                        navigate,
                        employees = employees,
                        team = teams,
                        modifier = Modifier.padding(innerpadding)
                    )
                }
            }
        }
    }
}

@Composable
fun MainUI(navigate: NavHostController) {
    var expanded by remember { mutableStateOf(false) }
    val items = listOf(
        MiniFabItems(Icons.Default.Add, "Add Team", Routes.ADD_TEAM_SCREEN),
        MiniFabItems(Icons.Filled.Person, "Add Employee", Routes.ADD_EMPLOYEE_SCREEN),
    )
    Column(horizontalAlignment = Alignment.End) {
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn() + slideInVertically(initialOffsetY = { it }) + expandVertically(),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { it }) + shrinkVertically()
        ) {
            Column(Modifier.padding(bottom = 8.dp)) {
                ItemUi(
                    icon = items[0].icon,
                    title = items[0].title,
                    route = items[0].routes,
                    navigate
                )
                Spacer(modifier = Modifier.height(8.dp))
                ItemUi(
                    icon = items[1].icon,
                    title = items[1].title,
                    route = items[1].routes,
                    navigate
                )


            }
        }
        val transition = updateTransition(targetState = expanded, label = "transition")
        val rotation by transition.animateFloat(label = "rotation") {
            if (it) 315f else 0f
        }

        FloatingActionButton(
            onClick = { expanded = !expanded }
        ) {
            Icon(
                imageVector = Icons.Filled.Add, contentDescription = "",
                modifier = Modifier.rotate(rotation)
            )
        }
    }
}


@Composable
fun ItemUi(icon: ImageVector, title: String, route: String, navigate: NavHostController) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
        Spacer(modifier = Modifier.weight(1f))
        Box(
            modifier = Modifier
                .border(
                    2.dp, MaterialTheme.colorScheme.primary,
                    RoundedCornerShape(10.dp)
                )
                .padding(6.dp)
        ) {
            Text(text = title)
        }
        Spacer(modifier = Modifier.width(10.dp))
        FloatingActionButton(
            onClick = {
                if (route == Routes.ADD_TEAM_SCREEN) {
                    navigate.navigate(Routes.ADD_TEAM_SCREEN)
                } else {
                    navigate.navigate(Routes.ADD_EMPLOYEE_SCREEN)
                }

            }, modifier = Modifier.size(45.dp)
//            , containerColor = Color(0xFFFF9800)
        ) {
            Icon(imageVector = icon, contentDescription = "")
        }
    }
}


@Composable
fun BottomNavigation(
    items: List<BottomNavigationItem> = listOf(),
    currentScreen: String,
    onItemClick: (String) -> Unit
) {
    NavigationBar {
        items.forEach { item ->
            NavigationBarItem(
                selected = currentScreen == item.route,
                label = { Text(text = item.title) }, onClick = { onItemClick(item.route) },
                alwaysShowLabel = currentScreen == item.route,
                icon = { Icon(imageVector = item.icon, contentDescription = "") }
            )

        }
    }
}
