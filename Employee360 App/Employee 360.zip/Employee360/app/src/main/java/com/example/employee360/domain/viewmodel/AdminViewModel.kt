package com.example.employee360.domain.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.example.employee360.common.util.Routes
import com.example.employee360.common.util.UiState
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.datalayer.module.Team
import com.example.employee360.datalayer.repository.CredentialRepository
import com.example.employee360.datalayer.repository.EmployeeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class AdminViewModel @Inject constructor(
    private val credentialRepository: CredentialRepository,
    private val repository: EmployeeRepository
) : ViewModel() {
    var currentRoute by mutableStateOf(Routes.ADMIN_DASHBOARD_SCREEN)

    var emailError by mutableStateOf(false)
    var errorMessage by mutableStateOf("")

    var employeeName by mutableStateOf("")

    var employeeDesignation by mutableStateOf("Employee")

    var employeeEmail by mutableStateOf("")

    var employeeSalary by mutableStateOf("")

    var selectedImage by mutableStateOf<Uri?>(null)
    var employeePassword by mutableStateOf("")


    var teamName by
    mutableStateOf("")

    var managerName by
    mutableStateOf("")

    var managerPassword by
    mutableStateOf("")

    var managerDesignation by
    mutableStateOf("Manager")

    var managerSalary by
    mutableStateOf("")

    var managerSelectedImage by
    mutableStateOf<Uri?>(null)

    var managerEmail by mutableStateOf("")

    private val _employee = MutableStateFlow<List<EmployeeDetails>>(emptyList())
    val employee: StateFlow<List<EmployeeDetails>> = _employee


    private val _team = MutableStateFlow<List<Team>>(emptyList())
    val team: StateFlow<List<Team>> = _team

    var uiState: UiState by mutableStateOf(UiState.Loading)
        private set

    init {
        uiState = UiState.Loading
        viewModelScope.launch {
            delay(1000L)
//            withContext(Dispatchers.IO) {
//                repository.deleteAllEmployee()
//                Log.d("msg", team.toString())
//
//            }
            repository.getEmployees().collect { employeeList ->
                _employee.value = employeeList
            }
        }
        updateTeam()
        uiState=UiState.Success

    }

    fun insertTeam(context: Context, employeeTeam: String, image: String) {

        viewModelScope.launch {
            val bitmap = getBitmap(context, image)
            val employee = bitmap?.let {
                EmployeeDetails(
                    name = managerName,
                    id = 0,
                    designation = "Manager",
                    team = employeeTeam,
                    salary = managerSalary,
                    password = managerPassword,
                    email = managerEmail,
                    profileImageUrl = it
                )
            }
            employee?.let {
                withContext(Dispatchers.IO) {
                    repository.insert(it)
                }
            }

        }
    }

    fun delete(employeeDetails: EmployeeDetails) {
        viewModelScope.launch {
            repository.delete(employeeDetails)
        }
        _employee.value = _employee.value.minus(employeeDetails)
        updateTeam()

    }

    fun insertEmployee(context: Context, employeeTeam: String, image: String) {

        viewModelScope.launch {
            val bitmap = getBitmap(context, image)
            val employee = bitmap?.let {
                EmployeeDetails(
                    name = employeeName.trim(),
                    id = 0,
                    designation = employeeDesignation.trim(),
                    team = employeeTeam.trim(),
                    salary = employeeSalary.trim(),
                    password = employeePassword.trim(),
                    email = employeeEmail.trim(),
                    profileImageUrl = it
                )
            }
            employee?.let {
                withContext(Dispatchers.IO) {
                    repository.insert(it)
//                    Log.d("msg", employee.toString())

                }
            }

        }
    }

    private suspend fun getBitmap(context: Context, url: String): Bitmap? {

        val imageLoader = ImageLoader(context)
        val request = ImageRequest.Builder(context)
            .data(url)
            .build()

        val result = imageLoader.execute(request)
        return (result as? SuccessResult)?.drawable?.toBitmap()
    }

    fun updateTeam() {
        viewModelScope.launch {
            Log.d("team Update enter", "entered")
            // Collect on the IO thread
            withContext(Dispatchers.IO) {
                repository.getTeam().collect { teamList ->
                    // Update state on the Main thread
                    withContext(Dispatchers.Main) {
                        _team.value = teamList
                        Log.d("team Update", teamList.toString())
                    }
                }
            }
        }
    }

    fun deleteAllCredential() {
        viewModelScope.launch {
            credentialRepository.getAllCredential()
        }
    }

    fun validateEmail(email: String) {
        if (employee.value.any { it.email==email }) {
            emailError = true
            errorMessage = "Email already exists"
        } else {
            emailError = false
            errorMessage = ""
        }
    }


}