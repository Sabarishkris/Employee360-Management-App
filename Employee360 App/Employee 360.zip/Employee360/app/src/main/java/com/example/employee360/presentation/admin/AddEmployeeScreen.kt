package com.example.employee360.presentation.admin

import android.annotation.SuppressLint
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.PopupProperties
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.example.employee360.datalayer.module.Team
import com.example.employee360.domain.viewmodel.AdminViewModel


@SuppressLint("CheckResult")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEmployeeScreen(navigate: NavHostController, viewModel: AdminViewModel = hiltViewModel()) {

    var expanded by remember { mutableStateOf(false) }
    val team by viewModel.team.collectAsState()


    val options = team.map { it.team }

    var selectedOption by remember { mutableStateOf(options.firstOrNull() ?: "") }

    LaunchedEffect(options) {

        selectedOption = options.firstOrNull() ?: ""
    }
    val context = LocalContext.current


    var employeeTeam by remember { mutableStateOf(TextFieldValue(selectedOption)) }

    val isError = viewModel.emailError
    val errorMessage = viewModel.errorMessage

    val photo =
        rememberLauncherForActivityResult(contract = ActivityResultContracts.PickVisualMedia(),
            onResult = { uri -> viewModel.selectedImage = uri })
    Scaffold(
        topBar = {
            TopAppBar(title = {
                Text("Add Employee ")
            },
                navigationIcon = {
                    IconButton(onClick = { navigate.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                })
        }
    ) { innerpadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerpadding)
                .verticalScroll(rememberScrollState())
        ) {

            OutlinedTextField(
                value = viewModel.employeeName,
                onValueChange = { viewModel.employeeName = it },
                label = { Text(text = "Employee Name") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                singleLine = true,
                maxLines = 1
            )
//            OutlinedTextField(
//                value = viewModel.employeeDesignation,
//                onValueChange = { viewModel.employeeDesignation = it },
//                label = { Text(text = "Employee Designation") },
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .padding(8.dp),
//                singleLine = true,
//                maxLines = 1
//            )

            OutlinedTextField(
                value = employeeTeam,
                onValueChange = { employeeTeam = it },
                readOnly = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .clickable { expanded = true },
                label = { Text("Choose Team") },
                trailingIcon = {
                    Icon(
                        imageVector = Icons.Filled.ArrowDropDown,
                        contentDescription = "Dropdown Icon",
                        modifier = Modifier.clickable {
                            expanded = true
                        }
                    )
                }
            )

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.fillMaxWidth(),
                properties = PopupProperties(focusable = true)
            ) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = {
                            selectedOption = option
                            employeeTeam =
                                TextFieldValue(option)
                            expanded = false
                        }
                    )
                }
            }

            OutlinedTextField(
                value = viewModel.employeeEmail,
                onValueChange = { newValue ->
                    viewModel.employeeEmail = newValue
                    viewModel.validateEmail(newValue)
                },
                label = { Text(text = "Email") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Done
                ),
                isError = isError,
                trailingIcon = {
                    if (isError) {
                        Icon(
                            imageVector = Icons.Default.Error,
                            contentDescription = "Error",
                            tint = Color.Red
                        )
                    }
                },
                supportingText = {
                    if (isError) {
                        Text(
                            text = errorMessage,
                            color = Color.Red
                        )
                    }
                }
            )
            OutlinedTextField(
                value = viewModel.employeeSalary,
                onValueChange = { viewModel.employeeSalary = it },
                label = { Text(text = "Salary") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.Decimal,
                    imeAction = ImeAction.Done
                )
            )
            OutlinedTextField(
                value = viewModel.employeePassword,
                onValueChange = { viewModel.employeePassword = it },
                label = { Text(text = "Credential Password") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                singleLine = true,
                maxLines = 1,
            )
            if (viewModel.selectedImage == null) {
                Button(modifier = Modifier.align(Alignment.CenterHorizontally), onClick = {
                    photo.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                }) {
                    Text(
                        text = "Select content Image",
                        fontSize = MaterialTheme.typography.titleMedium.fontSize,
                        fontWeight = MaterialTheme.typography.titleMedium.fontWeight
                    )
                }
            } else {
                AsyncImage(
                    model = viewModel.selectedImage, contentDescription = null,
                    modifier = Modifier
                        .size(200.dp)
                        .clip(RectangleShape)
                        .padding(8.dp),
                    contentScale = ContentScale.Crop
                )
//                GlideImage(
//                    imageUri = selectedImage!!,
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .height(200.dp)
//                        .padding(16.dp)
//                )
            }



            if (viewModel.selectedImage != null && viewModel.employeeName.isNotBlank()
                && employeeTeam.text.trim().isNotBlank()
                && viewModel.employeeDesignation.trim().isNotBlank()
                && !viewModel.emailError
                && viewModel.employeePassword.trim().isNotBlank()
                && viewModel.employeeSalary.trim().isNotBlank()
                && viewModel.employeeEmail.trim().isNotBlank()
            ) {
                Button(modifier = Modifier.align(Alignment.CenterHorizontally),
                    onClick = {

                        viewModel.insertEmployee(
                            context,
                            employeeTeam.text.trim(),
                            viewModel.selectedImage.toString()
                        )
                        navigate.popBackStack()

                    }) {
                    Text(
                        text = "Save",
                        fontSize = MaterialTheme.typography.titleMedium.fontSize,
                        fontWeight = MaterialTheme.typography.titleMedium.fontWeight
                    )
                }
            }

        }
    }
}