package com.example.employee360.common.util

object Routes {
    const val LOGIN_SCREEN="login_screen"
    const val ADMIN_DASHBOARD_SCREEN = "admin_dashboard_screen"
    const val ADMIN_LIST_SCREEN = "admin_list_screen"
    const val ADMIN_SETTING_SCREEN = "admin_setting_screen"
    const val ADD_TEAM_SCREEN="add_team_screen"
    const val ADD_EMPLOYEE_SCREEN="add_employee_screen"
    const val MANAGER_DASHBOARD_SCREEN = "manager_dashboard_screen"
    const val MANAGER_LIST_SCREEN = "manager_list_screen"
    const val MANAGER_SETTING_SCREEN = "manager_setting_screen"
    const val EMPLOYEE_DETAIL_SCREEN = "employee_detail_screen"
    const val EMPLOYEE_SETTING_SCREEN = "employee_setting_screen"
    const val EMPLOYEE_VIEW="employee_view"
    const val FORGOT_PASSWORD_SCREEN="forgot_password_screen"
}