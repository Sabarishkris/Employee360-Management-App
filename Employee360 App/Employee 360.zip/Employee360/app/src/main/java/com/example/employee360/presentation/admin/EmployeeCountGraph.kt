package com.example.employee360.presentation.admin

import android.graphics.Color
import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.employee360.datalayer.module.Team
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter

//
//@Composable
//fun EmployeeCountGraph(teams: List<Team>) {
//    val barWidth = 40.dp
//    val spacing = 16.dp
//    val maxTeamCount = teams.maxOf { it.teamCount }
//
//    val barColor = MaterialTheme.colorScheme.primary
//    val labelColor = MaterialTheme.colorScheme.onSurface
//    val axisLineColor = MaterialTheme.colorScheme.secondary
//
//    Canvas(modifier = Modifier
//        .fillMaxWidth()
//        .height(300.dp)
//        .padding(16.dp)
//    ) {
//        val canvasWidth = size.width
//        val canvasHeight = size.height
//        val barSpacing = barWidth.toPx() + spacing.toPx()
//        val barHeightFactor = canvasHeight / (maxTeamCount.toFloat())
//
//        drawLine(
//            color = axisLineColor,
//            start = Offset(0f, canvasHeight),
//            end = Offset(canvasWidth, canvasHeight),
//            strokeWidth = 5f
//        )
//
//        teams.forEachIndexed { index, team ->
//
//            val barHeight = team.teamCount * barHeightFactor
//
//            drawRoundRect(
//                color = barColor,
//                topLeft = Offset(x = index * barSpacing, y = canvasHeight - barHeight),
//                size = androidx.compose.ui.geometry.Size(barWidth.toPx(), barHeight),
//                cornerRadius = CornerRadius(10f, 10f)
//            )
//
//
//            val paint = Paint().apply {
//                color = labelColor.toArgb()
//                textSize = 30f
//                textAlign = Paint.Align.CENTER
//            }
//
//
//            drawContext.canvas.nativeCanvas.drawText(
//                team.team,
//                index * barSpacing + barWidth.toPx() / 2,
//                canvasHeight + 40f,
//                paint
//            )
//        }
//    }
//}


@Composable
fun EmployeeCountGraph(teams: List<Team>) {

    val axisTextColor = MaterialTheme.colorScheme.onSurface.toArgb()
    var axisLineColorm = MaterialTheme.colorScheme.primary.toArgb()
    val valueLabelColor = MaterialTheme.colorScheme.secondary.toArgb()

    AndroidView(
        factory = { context ->
            BarChart(context).apply {
                description.isEnabled = false
                setDrawGridBackground(false)


                xAxis.apply {
                    position = XAxis.XAxisPosition.BOTTOM
                    setDrawGridLines(false)
                    granularity = 1f
                    isGranularityEnabled = true


                    textColor = axisTextColor
                    axisLineColor = axisLineColorm
                }


                axisLeft.apply {
                    setDrawGridLines(false)
                    textColor = axisTextColor
                    axisLineColor = axisLineColorm
                }


                axisRight.isEnabled = false
            }
        },
        update = { chart ->

            val entries = teams.mapIndexed { index, team ->
                BarEntry(index.toFloat(), team.teamCount.toFloat())
            }

            val colors = listOf(
                Color.BLUE, Color.RED, Color.GREEN, Color.MAGENTA, Color.CYAN
            )

            val dataSet = BarDataSet(entries, "Teams").apply {
                setColors(colors)

                valueTextColor = valueLabelColor
            }

            val data = BarData(dataSet)
            chart.data = data


            chart.xAxis.valueFormatter = IndexAxisValueFormatter(teams.map { it.team })


            chart.invalidate()
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp)
    )
}

//
//@Composable
//fun EmployeeCountGraph(teams: List<Team>) {
//    AndroidView(
//        factory = { context ->
//            BarChart(context).apply {
//                description.isEnabled = false
//                setDrawGridBackground(false)
//
//
//                xAxis.apply {
//                    position = XAxis.XAxisPosition.BOTTOM
//                    setDrawGridLines(false)
//                    granularity = 1f
//                    isGranularityEnabled = true
//                }
//
//                axisRight.isEnabled = false
//            }
//        },
//        update = { chart ->
//
//            val entries = teams.mapIndexed { index, team ->
//                BarEntry(index.toFloat(), team.teamCount.toFloat())
//            }
//
//            val colors = listOf(
//                Color.BLUE, Color.RED, Color.GREEN, Color.MAGENTA, Color.CYAN
//            )
//
//            val dataSet = BarDataSet(entries, "Teams").apply {
//                setColors(colors)
//
//            }
//
//            val data = BarData(dataSet)
//            chart.data = data
//
//            chart.xAxis.valueFormatter = IndexAxisValueFormatter(teams.map { it.team
//            })
//
//            chart.invalidate()
//        },
//        modifier = Modifier
//            .fillMaxWidth()
//            .height(300.dp)
//    )
//}