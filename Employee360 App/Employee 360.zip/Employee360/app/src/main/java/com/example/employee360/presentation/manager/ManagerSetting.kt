package com.example.employee360.presentation.manager


import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.presentation.employee.EmployeeHomeScreen

@Composable
fun ManagerSetting(navigate: NavHostController, manager:EmployeeDetails, modifier:Modifier) {

    EmployeeHomeScreen(navigate, employeeDetails = manager, modifier = modifier, true)

}