package com.example.employee360.domain.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.employee360.common.util.UiState
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.datalayer.repository.EmployeeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ManagerViewModel @Inject constructor(private val repository: EmployeeRepository) :
    ViewModel() {
    private val _employee = MutableStateFlow<List<EmployeeDetails>>(emptyList())
    val employee: StateFlow<List<EmployeeDetails>> = _employee
    var uiState: UiState by mutableStateOf(UiState.Loading)
        private set

    init {
        uiState = UiState.Loading
        viewModelScope.launch {
            repository.getEmployees().collect { employeeList ->
                _employee.value = employeeList
            }
        }
        uiState = UiState.Success
    }

}