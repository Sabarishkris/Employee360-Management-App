package com.example.employee360.presentation.manager

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.employee360.common.module.BottomNavigationItem
import com.example.employee360.common.util.Routes
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.domain.viewmodel.ManagerViewModel
import com.example.employee360.presentation.admin.BottomNavigation

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManagerMainScreen(
    navigate: NavHostController,
    manager:EmployeeDetails,
    viewModel: ManagerViewModel = hiltViewModel()
) {
    val employee by viewModel.employee.collectAsState()
    val employees = employee.filter { it.team == manager.team }
    var currentRoute by remember {
        mutableStateOf(Routes.MANAGER_DASHBOARD_SCREEN)
    }
    val items = listOf(
        BottomNavigationItem(
            "Search",
            Routes.MANAGER_LIST_SCREEN,
            icon = Icons.Default.Search
        ), BottomNavigationItem(
            "Home",
            Routes.MANAGER_DASHBOARD_SCREEN,
            icon = Icons.Default.Home
        ),
        BottomNavigationItem(
            "Setting",
            Routes.MANAGER_SETTING_SCREEN,
            icon = Icons.Default.Settings
        )
    )
    Scaffold(
        topBar = {
            TopAppBar(title = {
                if (currentRoute == Routes.MANAGER_DASHBOARD_SCREEN) {
                    Text("Hello ${manager.name}")
                } else if (currentRoute == Routes.MANAGER_LIST_SCREEN) {
                    Text("Search")
                } else if (currentRoute == Routes.MANAGER_SETTING_SCREEN) {
                    Text("Setting")
                }
            })
        },
        bottomBar = {
            BottomNavigation(items = items, currentScreen = currentRoute) {
                currentRoute = it
            }
        }
    ) { innerpadding ->
        when (currentRoute) {
            Routes.MANAGER_DASHBOARD_SCREEN -> {
                ManagerHomeScreen(modifier = Modifier.padding(innerpadding), navigate = navigate, employees = employees)
            }

            Routes.MANAGER_LIST_SCREEN -> {
                ManagerListScreen(navigate,employees, modifier = Modifier.padding(innerpadding))
            }

            Routes.MANAGER_SETTING_SCREEN -> {
                ManagerSetting(navigate,manager=manager, modifier =  Modifier.padding(innerpadding))

            }
        }
    }
}
