package com.example.employee360.datalayer.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.newsappjetpack.datalayer.converters.Converters


@Database(entities = [EmployeeDetails::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class EmployeeDataBase: RoomDatabase() {
    abstract val dao:EmployeeDao
}