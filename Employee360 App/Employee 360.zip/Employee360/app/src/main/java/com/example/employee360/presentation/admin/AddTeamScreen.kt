package com.example.employee360.presentation.admin

import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.example.employee360.common.util.Routes
import com.example.employee360.domain.viewmodel.AdminViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTeamScreen(navigate: NavHostController,viewModel: AdminViewModel = hiltViewModel()) {

    val context = LocalContext.current
    val photo =
        rememberLauncherForActivityResult(contract = ActivityResultContracts.PickVisualMedia(),
            onResult = { uri -> viewModel.managerSelectedImage = uri })

    val isError = viewModel.emailError
    val errorMessage = viewModel.errorMessage
    Scaffold(
        topBar = {
            TopAppBar(title = {
                Text("Add Team ")
            },
                navigationIcon = {
                    IconButton(onClick = { navigate.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                })
        }
    ) { innerpadding ->


        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerpadding)
                .verticalScroll(rememberScrollState())
        ) {
            OutlinedTextField(
                value = viewModel.teamName,
                onValueChange = { viewModel.teamName = it },
                label = { Text(text = "Team Name") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                singleLine = true,
                maxLines = 1
            )
            OutlinedTextField(
                value = viewModel.managerName,
                onValueChange = { viewModel.managerName = it },
                label = { Text(text = "Manager Name") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                singleLine = true,
                maxLines = 1
            )

//            OutlinedTextField(
//                value = viewModel.managerEmail,
//                onValueChange = { viewModel.managerEmail= it },
//                label = { Text(text = "Email") },
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .padding(8.dp),
//                singleLine = true,
//                maxLines = 1,
//                keyboardOptions = KeyboardOptions(
//                    autoCorrect = false,
//                    keyboardType = KeyboardType.Email,
//                    imeAction = ImeAction.Done
//                )
//            )
            OutlinedTextField(
                value = viewModel.employeeEmail,
                onValueChange = { newValue ->
                    viewModel.employeeEmail = newValue
                    viewModel.validateEmail(newValue)
                },
                label = { Text(text = "Email") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Done
                ),
                isError = isError,
                trailingIcon = {
                    if (isError) {
                        Icon(
                            imageVector = Icons.Default.Error,
                            contentDescription = "Error",
                            tint = Color.Red
                        )
                    }
                },
                supportingText = {
                    if (isError) {
                        Text(
                            text = errorMessage,
                            color = Color.Red
                        )
                    }
                }
            )
            OutlinedTextField(
                value = viewModel.managerSalary,
                onValueChange = { viewModel.managerSalary = it },
                label = { Text(text = "Salary") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                singleLine = true,
                maxLines = 1,
                keyboardOptions = KeyboardOptions(
                    autoCorrect = false,
                    keyboardType = KeyboardType.Decimal,
                    imeAction = ImeAction.Done
                )
            )
            OutlinedTextField(
                value = viewModel.managerPassword,
                onValueChange = { viewModel.managerPassword = it },
                label = { Text(text = "Credential Password") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                singleLine = true,
                maxLines = 1
            )
            if (viewModel.managerSelectedImage == null) {
                Button(modifier = Modifier.align(Alignment.CenterHorizontally), onClick = {
                    photo.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                }) {
                    Text(
                        text = "Select content Image",
                        fontSize = MaterialTheme.typography.titleMedium.fontSize,
                        fontWeight = MaterialTheme.typography.titleMedium.fontWeight
                    )
                }
            } else {
                AsyncImage(
                    model = viewModel.managerSelectedImage, contentDescription = null,
                    modifier = Modifier
                        .size(200.dp)
                        .clip(RectangleShape)
                        .padding(8.dp),
                    contentScale = ContentScale.Crop
                )
            }
            if (viewModel.managerSelectedImage != null && viewModel.managerName.trim().isNotBlank()
                && viewModel.managerDesignation.trim().isNotBlank()
                && viewModel.managerPassword.trim().isNotBlank()
                && !viewModel.emailError
                && viewModel.managerSalary.trim().isNotBlank()
            ) {
                Button(modifier = Modifier.align(Alignment.CenterHorizontally),
                    onClick = {
                        viewModel.insertTeam(
                            context,
                            viewModel.teamName.trim(),
                            viewModel.managerSelectedImage.toString()
                        )
                        viewModel.updateTeam()
                        navigate.popBackStack()
                    }) {
                    Text(
                        text = "Save",
                        fontSize = MaterialTheme.typography.titleMedium.fontSize,
                        fontWeight = MaterialTheme.typography.titleMedium.fontWeight
                    )
                }
            }


        }
    }
}