package com.example.employee360.presentation.employee

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.employee360.common.module.BottomNavigationItem
import com.example.employee360.common.util.Routes
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.domain.viewmodel.LoginViewModel
import com.example.employee360.presentation.admin.BottomNavigation

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun EmployeeMainScreen(navigate: NavHostController,
                       employeeDetails: EmployeeDetails,
                       loginViewModel: LoginViewModel= hiltViewModel()) {
    var currentRoute by remember {
        mutableStateOf(Routes.EMPLOYEE_DETAIL_SCREEN)
    }
    val items = listOf(
        BottomNavigationItem(
            "Home",
            Routes.EMPLOYEE_DETAIL_SCREEN,
            icon = Icons.Default.Home
        ),
    )
    Scaffold(
        topBar = {
            TopAppBar(title = {
                if (currentRoute == Routes.EMPLOYEE_DETAIL_SCREEN) {
                    Text("Hello ${employeeDetails.name}")
                } else if (currentRoute == Routes.EMPLOYEE_SETTING_SCREEN) {
                    Text("Setting")
                }
            }, actions = {
                IconButton(onClick = {
                    loginViewModel.deleteAllCredential()
                    navigate.popBackStack(Routes.LOGIN_SCREEN,false)
                }) {
                    Icon(
                        imageVector = Icons.Filled.Logout,
                        contentDescription = "SignOut",
                    )

                }
            })
        },
        bottomBar = {
            BottomNavigation(items = items, currentScreen = currentRoute) {
                currentRoute = it
            }
        }
    ) { innerPadding ->

        when (currentRoute) {
            Routes.EMPLOYEE_DETAIL_SCREEN -> {
                EmployeeHomeScreen(navigate,employeeDetails, modifier = Modifier.padding(innerPadding),false)
            }

        }
    }
}


@Composable
fun EmployeeRow(icon: ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    }
}
