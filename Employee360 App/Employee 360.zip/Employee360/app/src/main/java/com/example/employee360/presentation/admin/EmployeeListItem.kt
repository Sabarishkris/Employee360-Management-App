package com.example.employee360.presentation.admin

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.example.employee360.common.util.Routes
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.datalayer.module.Team


@Composable
fun EmployeeListItem(employee: EmployeeDetails, navigate: NavHostController) {
    Column(modifier = Modifier
        .fillMaxWidth()
        .clickable {
            navigate.currentBackStackEntry?.savedStateHandle?.set(
                key = "data",
                value = employee
            )
            navigate.navigate(Routes.EMPLOYEE_VIEW)
        }) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = employee.profileImageUrl, contentDescription = null,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .border(2.dp, Color.Gray, CircleShape),
                contentScale = ContentScale.Crop
            )


//            GlideImage(
//                imageUrl = employee.profileImageUrl,
//                modifier = Modifier
//                    .size(64.dp)
//                    .clip(CircleShape)
//                    .border(2.dp, Color.Gray, CircleShape)
//            )

            Spacer(modifier = Modifier.width(16.dp))

            Column {
                Text(
                    text = employee.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = MaterialTheme.typography.titleMedium.fontWeight
                )
                Text(text = employee.designation, style = MaterialTheme.typography.bodyMedium)
                Text(text = "Team : ${employee.team}", style = MaterialTheme.typography.bodyMedium)
                Text(
                    text = "Salary : $ ${employee.salary}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

    }
    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
}
