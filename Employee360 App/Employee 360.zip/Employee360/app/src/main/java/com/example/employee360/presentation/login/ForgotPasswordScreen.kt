package com.example.employee360.presentation.login

import android.util.Log
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape

import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.employee360.R
import com.example.employee360.domain.viewmodel.LoginViewModel


@Composable
fun ForgotPasswordScreen(
    navController: NavHostController,
    viewModel: LoginViewModel = hiltViewModel()
) {
    val isImeVisible by rememberImeState()
    val context = LocalContext.current
    val animatedUpperSectionRatio by animateFloatAsState(
        targetValue = if (isImeVisible) 0f else 0.35f,
        label = "",
    )
    GradientBox(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {


            AnimatedVisibility(visible = !isImeVisible, enter = fadeIn(), exit = fadeOut()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(animatedUpperSectionRatio),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Bottom,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Forgot Password",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onPrimary,
                        )
                        Image(
                            painter = painterResource(id = R.drawable.forgot),
                            contentDescription = "Login Image",
                            modifier = Modifier.size(150.dp)
                        )
                    }

                }
            }
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp))
                    .background(MaterialTheme.colorScheme.surface),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Text(
                    text = "Create New Password",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(16.dp)
                )

//        Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = viewModel.email,
                    onValueChange = { viewModel.email = it },
                    label = { Text(text = "Email") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    singleLine = true,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = viewModel.newPassword,
                    onValueChange = { viewModel.newPassword = it },
                    label = { Text(text = "New Password") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    singleLine = true,
                    maxLines = 1
                )

                Spacer(modifier = Modifier.height(16.dp))


                if (isImeVisible) {
                    if (viewModel.email.trim().isNotBlank() &&
//                viewModel.designation.trim().isNotBlank() &&
//                viewModel.team.trim().isNotBlank() &&
                        viewModel.newPassword.trim().isNotBlank()
                    ) {
                        Button(modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 20.dp)
                            .padding(horizontal = 16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.surface
                            ),
                            shape = RoundedCornerShape(10.dp),
                            onClick = {
                                if (viewModel.contains(
                                        viewModel.email.trim(),
                                        viewModel.designation.trim(),
                                        viewModel.team.trim(),
                                        viewModel.newPassword.trim()
                                    )
                                ) {
                                    Log.d("emp contain", "true ")
                                    viewModel.validate(
                                        viewModel.email.trim(),
                                        viewModel.designation.trim(),
                                        viewModel.team.trim(),
                                        viewModel.newPassword.trim()
                                    )
                                    navController.popBackStack()
                                } else {
                                    Toast.makeText(context, "Invalid details ", Toast.LENGTH_SHORT)
                                        .show()
                                }

                            }) {
                            Text(
                                text = "Change Password ",
                                fontSize = MaterialTheme.typography.titleMedium.fontSize,
                                fontWeight = MaterialTheme.typography.titleMedium.fontWeight
                            )
                        }
                    }

                } else {

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp), contentAlignment = Alignment.CenterStart
                    ) {

                        if (viewModel.email.trim().isNotBlank() &&
//                viewModel.designation.trim().isNotBlank() &&
//                viewModel.team.trim().isNotBlank() &&
                            viewModel.newPassword.trim().isNotBlank()
                        ) {
                            Button(modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                shape = RoundedCornerShape(10.dp),
                                onClick = {
                                    if (viewModel.contains(
                                            viewModel.email.trim(),
                                            viewModel.designation.trim(),
                                            viewModel.team.trim(),
                                            viewModel.newPassword.trim()
                                        )
                                    ) {
                                        Log.d("emp contain", "true ")
                                        viewModel.validate(
                                            viewModel.email.trim(),
                                            viewModel.designation.trim(),
                                            viewModel.team.trim(),
                                            viewModel.newPassword.trim()
                                        )
                                        navController.popBackStack()
                                    } else {
                                        Toast.makeText(
                                            context,
                                            "Invalid details ",
                                            Toast.LENGTH_SHORT
                                        )
                                            .show()
                                    }

                                }) {
                                Text(
                                    text = "Change Password ",
                                    fontSize = MaterialTheme.typography.titleMedium.fontSize,
                                    fontWeight = MaterialTheme.typography.titleMedium.fontWeight
                                )
                            }
                        }

                    }
                }
            }


        }
    }
}
