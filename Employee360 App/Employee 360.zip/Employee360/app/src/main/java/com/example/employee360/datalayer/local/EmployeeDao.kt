package com.example.employee360.datalayer.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.datalayer.module.Team
import kotlinx.coroutines.flow.Flow

@Dao
interface EmployeeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(employee: EmployeeDetails)

    @Delete
    suspend fun delete(employee: EmployeeDetails)

    @Query("SELECT team, COUNT(team) as teamCount FROM employeedetails GROUP BY team ")
    fun getTeam(): Flow<List<Team>>

    @Query("select * from employeedetails")
    fun getReports(): Flow<List<EmployeeDetails>>

    @Query("delete from employeedetails")
    fun deleteall()
}