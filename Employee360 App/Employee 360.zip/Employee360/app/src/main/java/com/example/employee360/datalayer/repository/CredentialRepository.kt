package com.example.employee360.datalayer.repository

import com.example.employee360.datalayer.module.Credential
import com.example.employee360.datalayer.module.EmployeeDetails
import kotlinx.coroutines.flow.Flow

interface CredentialRepository {
    suspend fun insert(credential: Credential)

    suspend fun deleteAllCredential()

    suspend fun getAllCredential():Flow<List<Credential>>
}