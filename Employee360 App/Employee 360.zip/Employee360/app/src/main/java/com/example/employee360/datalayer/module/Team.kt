package com.example.employee360.datalayer.module

data class Team(
    val team: String,
    val teamCount: Int,
)